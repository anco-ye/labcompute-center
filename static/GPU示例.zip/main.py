import json
from pathlib import Path
import torch

x = torch.arange(4096, dtype=torch.float32, device="cuda").reshape(64, 64) / 4096
y = x @ x.T
torch.cuda.synchronize()
Path("outputs").mkdir(exist_ok=True)
Path("outputs/result.json").write_text(json.dumps({"sum": y.sum().item(), "gpu": torch.cuda.get_device_name(0)}))
